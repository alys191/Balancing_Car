﻿#===============================================================================
# ws63_ohos WSL 开发环境一键配置脚本
#
# 用法（以管理员身份运行 PowerShell）：
#   .\setup_wsl_ws63.ps1 -p 1              # 启用 WSL、安装内核更新，需重启
#   .\setup_wsl_ws63.ps1 -p 2              # 下载并导入 fbb_ws63_wsl（重启后执行）
#   .\setup_wsl_ws63.ps1 -p 2 -InstallDir "D:\ubuntu" -TarPath "D:\fbb_ws63_wsl.tar"
#
# 参数说明：
#   -p 1|2          阶段 1 或 2（因需重启，分两阶段执行）
#   -InstallDir     可选，WSL 发行版安装目录，默认 D:\ubuntu
#   -TarPath        可选，fbb_ws63_wsl.tar 保存路径，默认 %USERPROFILE%\Downloads\fbb_ws63_wsl.tar
#===============================================================================

param(
    [Parameter(Mandatory=$true)]
    [Alias("p")]
    [ValidateSet(1, 2)]
    [int]$Phase,
    [string]$InstallDir = "",
    [string]$TarPath = ""
)

# 检查管理员权限
$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Write-Host "错误：请以管理员身份运行 PowerShell" -ForegroundColor Red
    Write-Host "右键 PowerShell -> 以管理员身份运行" -ForegroundColor Yellow
    exit 1
}

$WslUpdateUrl = "https://wslstorestorage.blob.core.windows.net/wslblob/wsl_update_x64.msi"
$FbbWs63TarUrl = "https://hispark-obs.obs.cn-east-3.myhuaweicloud.com/fbb_ws63_wsl.tar"

if ($InstallDir -eq "") { $InstallDir = "D:\ubuntu" }
if ($TarPath -eq "") { $TarPath = Join-Path $env:USERPROFILE "Downloads\fbb_ws63_wsl.tar" }

#-------------------------------------------------------------------------------
# Phase 1: 启用 WSL、虚拟机平台、安装内核更新
#-------------------------------------------------------------------------------
if ($Phase -eq 1) {
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host "  Phase 1: 启用 WSL 并安装内核更新" -ForegroundColor Cyan
    Write-Host "========================================" -ForegroundColor Cyan

    Write-Host "`n[1/3] 启用 WSL 功能..." -ForegroundColor Green
    dism.exe /online /enable-feature /featurename:Microsoft-Windows-Subsystem-Linux /all /norestart
    if ($LASTEXITCODE -ne 0) { Write-Host "  WSL 可能已启用，继续..." -ForegroundColor Yellow }

    Write-Host "`n[2/3] 启用虚拟机平台..." -ForegroundColor Green
    dism.exe /online /enable-feature /featurename:VirtualMachinePlatform /all /norestart
    if ($LASTEXITCODE -ne 0) { Write-Host "  虚拟机平台可能已启用，继续..." -ForegroundColor Yellow }

    Write-Host "`n[3/3] 下载并安装 Linux 内核更新包..." -ForegroundColor Green
    $msiPath = Join-Path $env:TEMP "wsl_update_x64.msi"
    try {
        Invoke-WebRequest -Uri $WslUpdateUrl -OutFile $msiPath -UseBasicParsing
        Start-Process msiexec.exe -ArgumentList "/i", $msiPath, "/quiet", "/norestart" -Wait
        Write-Host "  ✓ 内核更新包已安装" -ForegroundColor Green
    } catch {
        Write-Host "  自动下载失败，请手动下载并安装：" -ForegroundColor Yellow
        Write-Host "  $WslUpdateUrl" -ForegroundColor Yellow
        exit 1
    }

    Write-Host "`n========================================" -ForegroundColor Cyan
    Write-Host "  Phase 1 完成！必须重启电脑。" -ForegroundColor Cyan
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host "`n重启后，以管理员身份再次运行本脚本，执行 Phase 2：" -ForegroundColor Yellow
    Write-Host "  .\setup_wsl_ws63.ps1 -p 2" -ForegroundColor White
    Write-Host "`n可选：指定安装目录和 tar 保存路径：" -ForegroundColor Gray
    Write-Host "  .\setup_wsl_ws63.ps1 -p 2 -InstallDir `"D:\ubuntu`" -TarPath `"D:\fbb_ws63_wsl.tar`"" -ForegroundColor Gray
    $restart = Read-Host "`n是否立即重启？(Y/N)"
    if ($restart -eq "Y" -or $restart -eq "y") { shutdown /r /t 60 }
    exit 0
}

#-------------------------------------------------------------------------------
# Phase 2: 下载 fbb_ws63_wsl.tar 并导入
#-------------------------------------------------------------------------------
if ($Phase -eq 2) {
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host "  Phase 2: 下载并导入 fbb_ws63_wsl" -ForegroundColor Cyan
    Write-Host "========================================" -ForegroundColor Cyan

    $tarDir = Split-Path $TarPath -Parent
    if (-not (Test-Path $tarDir)) {
        New-Item -ItemType Directory -Path $tarDir -Force | Out-Null
    }

    if (-not (Test-Path $TarPath)) {
        Write-Host "`n[1/2] 下载 fbb_ws63_wsl.tar（约 2GB+，请耐心等待）..." -ForegroundColor Green
        try {
            Invoke-WebRequest -Uri $FbbWs63TarUrl -OutFile $TarPath -UseBasicParsing
            Write-Host "  ✓ 下载完成：$TarPath" -ForegroundColor Green
        } catch {
            Write-Host "  自动下载失败，请手动下载后指定 -TarPath 参数：" -ForegroundColor Yellow
            Write-Host "  $FbbWs63TarUrl" -ForegroundColor Yellow
            exit 1
        }
    } else {
        Write-Host "`n[1/2] 已存在：$TarPath，跳过下载" -ForegroundColor Green
    }

    $installParent = Split-Path $InstallDir -Parent
    if (-not (Test-Path $installParent)) {
        New-Item -ItemType Directory -Path $installParent -Force | Out-Null
    }

    Write-Host "`n[2/2] 导入 WSL 发行版 fbb_ws63..." -ForegroundColor Green
    wsl --import fbb_ws63 $InstallDir $TarPath
    if ($LASTEXITCODE -eq 0) {
        Write-Host "  ✓ 导入完成" -ForegroundColor Green
        wsl --list
    } else {
        Write-Host "  导入失败" -ForegroundColor Red
        exit 1
    }

    Write-Host "`n========================================" -ForegroundColor Cyan
    Write-Host "  Phase 2 完成！" -ForegroundColor Cyan
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host "`n建议重启电脑以避免卡顿。" -ForegroundColor Yellow
    Write-Host "`n后续步骤（需手动）：" -ForegroundColor White
    Write-Host "  1. 安装 VSCode: https://code.visualstudio.com/" -ForegroundColor Gray
    Write-Host "  2. 安装 Remote Development 扩展" -ForegroundColor Gray
    Write-Host "  3. 打开 VSCode -> 远程资源管理器 -> 选择 fbb_ws63 -> 连接" -ForegroundColor Gray
    Write-Host "  4. 在 WSL 终端中运行下载脚本获取源码：bash /root/download_ws63_ohos.sh" -ForegroundColor Gray
    exit 0
}
