#!/bin/bash
#===============================================================================
# ws63_ohos 一键下载和配置开发环境脚本
# 用法：bash /root/download_ws63_ohos.sh [安装目录]
#       不指定目录时，默认安装到 $HOME/ws63_ohos
#===============================================================================

set -e

TARGET_DIR="${1:-$HOME/ws63_ohos}"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "=========================================="
echo "  ws63_ohos 一键下载和配置开发环境"
echo "=========================================="
echo "安装目录: $TARGET_DIR"
echo ""

#-------------------------------------------------------------------------------
# 1. 安装 repo 工具
#-------------------------------------------------------------------------------
echo "[1/7] 安装 repo 工具..."
mkdir -p ~/bin
if [ ! -f ~/bin/repo ]; then
    curl -sL https://gitee.com/oschina/repo/raw/fork_flow/repo-py3 -o ~/bin/repo
    chmod a+x ~/bin/repo
fi
pip3 install -q -i https://repo.huaweicloud.com/repository/pypi/simple requests 2>/dev/null || true
echo "  ✓ repo 已就绪"

#-------------------------------------------------------------------------------
# 2. 安装 git-lfs
#-------------------------------------------------------------------------------
echo "[2/7] 安装 git-lfs..."
if ! command -v git-lfs &>/dev/null; then
    sudo apt-get update -qq
    sudo apt-get install -y -qq git-lfs
fi
git lfs install 2>/dev/null || true
echo "  ✓ git-lfs 已就绪"

#-------------------------------------------------------------------------------
# 3. 配置 repo 环境变量
#-------------------------------------------------------------------------------
echo "[3/7] 配置 repo 环境变量..."
if ! grep -q 'export PATH=~/bin:\$PATH' ~/.bashrc 2>/dev/null; then
    echo 'export PATH=~/bin:$PATH' >> ~/.bashrc
fi
export PATH=~/bin:$PATH
echo "  ✓ PATH 已配置"

#-------------------------------------------------------------------------------
# 4. 通过 repo 下载源码
#-------------------------------------------------------------------------------
echo "[4/7] 通过 repo 下载源码（耗时较长，请耐心等待）..."
mkdir -p "$TARGET_DIR"
cd "$TARGET_DIR"

if [ ! -d .repo ]; then
    repo init -u https://gitee.com/HiSpark/manifest.git -b OpenHarmony-v5.1.0-Release -m default-ws63-without-xts.xml --no-repo-verify
fi
repo sync -c
repo forall -c 'git lfs pull'
echo "  ✓ 源码下载完成"

#-------------------------------------------------------------------------------
# 5. 下载预编译工具链
#-------------------------------------------------------------------------------
echo "[5/7] 下载预编译工具链..."
cd "$TARGET_DIR"
./build/prebuilts_download.sh
echo "  ✓ 预编译工具链下载完成"

#-------------------------------------------------------------------------------
# 6. 安装 hb 构建工具
#-------------------------------------------------------------------------------
echo "[6/7] 安装 hb 构建工具..."
cd "$TARGET_DIR"
python3 -m pip install --user build/hb -q
# pip --user 安装到 ~/.local/bin，需加入 PATH
LOCAL_BIN="$HOME/.local/bin"
if [ -d "$LOCAL_BIN" ]; then
    export PATH="$LOCAL_BIN:$PATH"
    if ! grep -qF "$LOCAL_BIN" ~/.bashrc 2>/dev/null; then
        echo "" >> ~/.bashrc
        echo "# pip --user 安装的可执行文件" >> ~/.bashrc
        echo "export PATH=\"$LOCAL_BIN:\$PATH\"" >> ~/.bashrc
        echo "  ✓ ~/.local/bin 已加入 ~/.bashrc"
    fi
fi
echo "  ✓ hb 已安装"

#-------------------------------------------------------------------------------
# 7. 安装 cmake（可选）
#-------------------------------------------------------------------------------
echo "[7/7] 安装 cmake..."
if ! command -v cmake &>/dev/null; then
    sudo apt-get install -y -qq cmake
fi
echo "  ✓ cmake 已就绪"

#-------------------------------------------------------------------------------
# 8. 配置工具链环境变量
#-------------------------------------------------------------------------------
TOOLCHAIN_PATH="$TARGET_DIR/device/soc/hisilicon/ws63v100/sdk/tools/bin/compiler/riscv/cc_riscv32_musl_100/cc_riscv32_musl/bin"
BASHRC_ENTRY="export PATH=$TOOLCHAIN_PATH:\$PATH"

if ! grep -qF "$TOOLCHAIN_PATH" ~/.bashrc 2>/dev/null; then
    echo "" >> ~/.bashrc
    echo "# ws63_ohos RISC-V 工具链" >> ~/.bashrc
    echo "$BASHRC_ENTRY" >> ~/.bashrc
    echo "  ✓ 工具链已写入 ~/.bashrc"
else
    echo "  ✓ 工具链已在 ~/.bashrc 中"
fi

#-------------------------------------------------------------------------------
# 完成提示
#-------------------------------------------------------------------------------
echo ""
echo "=========================================="
echo "  下载和配置完成！"
echo "=========================================="
echo ""
echo "请执行以下命令使环境变量生效："
echo "  source ~/.bashrc"
echo ""
echo "验证工具链："
echo "  riscv32-linux-musl-gcc -v"
echo ""
echo "【编译系统】在源码根目录执行："
echo "  cd $TARGET_DIR"
echo "  hb set -p nearlink_dk_3863"
echo "  hb build -f"
echo ""
echo "或一键完整编译（含清理）："
echo "  cd $TARGET_DIR"
echo "  rm -rf out && hb set -p nearlink_dk_3863 && hb build -f"
echo ""
echo "编译完成后，固件位于："
echo "  $TARGET_DIR/out/nearlink_dk_3863/nearlink_dk_3863/ws63-liteos-app/ws63-liteos-app_all.fwpkg"
echo ""
