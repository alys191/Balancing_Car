# ending_homework报错

可能是红外传感的驱动需要更换，请看到adchuman文件夹中的adc_driver目录，根据提示去替换一些驱动依赖。